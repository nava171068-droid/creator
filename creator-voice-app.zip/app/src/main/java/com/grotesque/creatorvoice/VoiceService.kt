package com.grotesque.creatorvoice

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.BitmapFactory
import android.graphics.PixelFormat
import android.graphics.drawable.BitmapDrawable
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.Toast
import java.io.ByteArrayOutputStream
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sqrt

class VoiceService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var lp: WindowManager.LayoutParams
    private var root: FrameLayout? = null
    private lateinit var bg: ImageView
    private lateinit var mic: ImageView
    private lateinit var btnUp: BitmapDrawable
    private lateinit var btnDown: BitmapDrawable
    private lateinit var micOn: BitmapDrawable
    private lateinit var micOff: BitmapDrawable
    private val ui = Handler(Looper.getMainLooper())
    private var ws: WsServer? = null
    private val worker = Executors.newSingleThreadExecutor()
    @Volatile private var listening = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startForegroundNow()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        ws = WsServer(this, 19131) { log(it) }.also { it.start() }
        buildButton()
        AppState.running = true
        log(getString(R.string.log_ready))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        listening = false
        AppState.listening = false
        AppState.running = false
        ws?.stop()
        try { root?.let { wm.removeView(it) } } catch (_: Exception) {}
        worker.shutdownNow()
        super.onDestroy()
    }

    private fun startForegroundNow() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("cv", "Creator Voice", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, "cv")
            .setContentTitle(getString(R.string.notif_title))
            .setContentText(getString(R.string.notif_text))
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(open)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(1, n)
        }
    }

    private fun log(s: String) {
        AppState.log(s)
        ui.post { Toast.makeText(this, s, Toast.LENGTH_SHORT).show() }
    }

    private fun px(id: Int): BitmapDrawable {
        val o = BitmapFactory.Options()
        o.inScaled = false
        val b = BitmapFactory.decodeResource(resources, id, o)
        val d = BitmapDrawable(resources, b)
        d.setFilterBitmap(false) // keep the pixel-art look
        return d
    }

    private fun buildButton() {
        btnUp = px(R.drawable.button)
        btnDown = px(R.drawable.button_pressed)
        micOn = px(R.drawable.microphone)
        micOff = px(R.drawable.microphone_off)
        val prefs = getSharedPreferences("cfg", MODE_PRIVATE)
        val size = (64 * resources.displayMetrics.density).toInt()
        val pad = size / 5

        val r = FrameLayout(this)
        bg = ImageView(this)
        bg.scaleType = ImageView.ScaleType.FIT_XY
        bg.setImageDrawable(btnUp)
        mic = ImageView(this)
        mic.scaleType = ImageView.ScaleType.FIT_CENTER
        mic.setImageDrawable(micOff)
        r.addView(bg, FrameLayout.LayoutParams(-1, -1))
        val ml = FrameLayout.LayoutParams(-1, -1)
        ml.setMargins(pad, pad, pad, pad)
        r.addView(mic, ml)

        lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = prefs.getInt("x", 40)
        lp.y = prefs.getInt("y", 300)

        var sx = 0f
        var sy = 0f
        var ox = 0
        var oy = 0
        var moved = false
        r.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false
                    bg.setImageDrawable(btnDown)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx
                    val dy = e.rawY - sy
                    if (!moved && (abs(dx) > 12 || abs(dy) > 12)) moved = true
                    if (moved) {
                        lp.x = (ox + dx).toInt()
                        lp.y = (oy + dy).toInt()
                        wm.updateViewLayout(r, lp)
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    bg.setImageDrawable(btnUp)
                    if (moved) {
                        prefs.edit().putInt("x", lp.x).putInt("y", lp.y).apply()
                    } else if (e.action == MotionEvent.ACTION_UP) {
                        toggle()
                    }
                    true
                }
                else -> false
            }
        }
        root = r
        wm.addView(r, lp)
    }

    private fun toggle() {
        if (listening) stopListening() else startListening()
    }

    private fun startListening() {
        val key = getSharedPreferences("cfg", MODE_PRIVATE).getString("key", "") ?: ""
        if (key.isBlank()) { log(getString(R.string.log_need_key)); return }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            log(getString(R.string.log_no_perm)); return
        }
        listening = true
        AppState.listening = true
        mic.setImageDrawable(micOn)
        Thread { recordLoop() }.start()
    }

    private fun stopListening() {
        listening = false
        AppState.listening = false
        mic.setImageDrawable(micOff)
    }

    private fun recordLoop() {
        val sr = 16000
        val chunk = sr / 5 // 200 ms
        val minBuf = AudioRecord.getMinBufferSize(sr, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val rec: AudioRecord
        try {
            rec = AudioRecord(
                MediaRecorder.AudioSource.MIC, sr, AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT, max(minBuf, chunk * 8)
            )
            if (rec.state != AudioRecord.STATE_INITIALIZED) throw IllegalStateException("mic busy")
            rec.startRecording()
        } catch (e: Exception) {
            log(getString(R.string.log_mic_fail, e.message ?: ""))
            ui.post { stopListening() }
            return
        }

        val buf = ShortArray(chunk)
        val pre = ArrayDeque<ShortArray>()
        var speech = ArrayList<ShortArray>()
        var inSpeech = false
        var quiet = 0
        var voiced = 0
        var noise = 300.0
        while (listening) {
            val n = rec.read(buf, 0, chunk)
            if (n <= 0) { Thread.sleep(20); continue }
            val c = buf.copyOf(n)
            var sum = 0.0
            for (i in 0 until n) sum += c[i].toDouble() * c[i].toDouble()
            val rms = sqrt(sum / n)
            val thr = max(700.0, noise * 3.0)
            if (!inSpeech) {
                if (rms > thr) {
                    inSpeech = true; quiet = 0; voiced = 1
                    speech = ArrayList()
                    speech.addAll(pre)
                    speech.add(c)
                } else {
                    noise = noise * 0.95 + rms * 0.05
                    pre.addLast(c)
                    if (pre.size > 3) pre.removeFirst()
                }
            } else {
                speech.add(c)
                if (rms < thr) quiet++ else { quiet = 0; voiced++ }
                if (quiet >= 4 || speech.size > 60) {
                    val data = speech
                    val ok = voiced >= 2
                    speech = ArrayList()
                    inSpeech = false; quiet = 0; voiced = 0
                    pre.clear()
                    if (ok) submit(data)
                }
            }
        }
        try { rec.stop() } catch (_: Exception) {}
        rec.release()
    }

    private fun wav(chunks: List<ShortArray>): ByteArray {
        var samples = 0
        for (c in chunks) samples += c.size
        val dataLen = samples * 2
        val o = ByteArrayOutputStream(44 + dataLen)
        fun i32(v: Int) { o.write(v and 255); o.write((v shr 8) and 255); o.write((v shr 16) and 255); o.write((v shr 24) and 255) }
        fun i16(v: Int) { o.write(v and 255); o.write((v shr 8) and 255) }
        o.write("RIFF".toByteArray()); i32(36 + dataLen); o.write("WAVEfmt ".toByteArray())
        i32(16); i16(1); i16(1); i32(16000); i32(32000); i16(2); i16(16)
        o.write("data".toByteArray()); i32(dataLen)
        for (c in chunks) for (s in c) i16(s.toInt())
        return o.toByteArray()
    }

    private fun submit(data: List<ShortArray>) {
        val key = getSharedPreferences("cfg", MODE_PRIVATE).getString("key", "") ?: ""
        val wavBytes = wav(data)
        worker.execute {
            try {
                val said = Groq.transcribe(key, wavBytes)
                if (said.isBlank()) return@execute
                log(getString(R.string.log_heard, said))
                val action = decide(key, said)
                if (action == "none") return@execute
                // action looks like "rain|1" or "give:diamond_sword:1|0"  (|1 = called by name)
                val clean = said.replace(Regex("[^\\p{L}\\p{M}\\p{N} ,.?!']"), " ").replace("|", " ").trim().take(120)
                val ok = ws?.sendCommand("scriptevent creator:voice $action|$clean") ?: false
                if (ok) AppState.log("-> $action") else log(getString(R.string.log_not_connected))
            } catch (e: Exception) {
                log(getString(R.string.log_error, e.message ?: ""))
            }
        }
    }

    private fun decide(key: String, said: String): String {
        // just the name -> call it, no AI needed
        // (works for any language: the name list is in Groq.NAME_REGEX)
        val words = said.lowercase().replace(Regex("[^\\p{L}\\p{M} ]"), " ").split(" ")
            .filter { it.isNotBlank() && it !in Groq.FILLERS }
        if (words.size == 1 && Groq.NAME_REGEX.matches(words[0])) return "summon|1"
        return try {
            Groq.classify(key, said)
        } catch (e: Exception) {
            AppState.log(getString(R.string.log_ai_failed))
            Groq.keywordAction(said)
        }
    }
}
