package com.grotesque.creatorvoice

import org.json.JSONObject
import java.io.IOException
import java.io.InputStream
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.security.MessageDigest
import java.util.Base64
import java.util.UUID

/** Tiny WebSocket server. Minecraft connects with:  /connect localhost:19131 */
class WsServer(private val port: Int, private val onLog: (String) -> Unit) {
    @Volatile private var server: ServerSocket? = null
    @Volatile private var client: Socket? = null
    private val lock = Any()

    fun start() {
        Thread {
            try {
                val ss = ServerSocket()
                ss.reuseAddress = true
                ss.bind(InetSocketAddress(port))
                server = ss
                while (!ss.isClosed) {
                    val s = ss.accept()
                    Thread { handle(s) }.start()
                }
            } catch (e: Exception) {
                if (server?.isClosed != true) onLog("Server error: ${e.message}")
            }
        }.start()
    }

    fun stop() {
        try { server?.close() } catch (_: Exception) {}
        synchronized(lock) {
            try { client?.close() } catch (_: Exception) {}
            client = null
        }
        AppState.minecraft = false
    }

    private fun readFully(ins: InputStream, buf: ByteArray) {
        var off = 0
        while (off < buf.size) {
            val n = ins.read(buf, off, buf.size - off)
            if (n < 0) throw IOException("closed")
            off += n
        }
    }

    private fun readHeader(ins: InputStream): String? {
        val sb = StringBuilder()
        while (sb.length < 8192) {
            val b = ins.read()
            if (b < 0) return null
            sb.append(b.toChar())
            if (sb.endsWith("\r\n\r\n")) return sb.toString()
        }
        return null
    }

    private fun handle(s: Socket) {
        try {
            s.tcpNoDelay = true
            val ins = s.getInputStream()
            val outs = s.getOutputStream()
            val header = readHeader(ins) ?: return
            val key = Regex("Sec-WebSocket-Key:\\s*(.+)", RegexOption.IGNORE_CASE)
                .find(header)?.groupValues?.get(1)?.trim() ?: return
            val digest = MessageDigest.getInstance("SHA-1")
                .digest((key + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11").toByteArray())
            val accept = Base64.getEncoder().encodeToString(digest)
            outs.write(
                ("HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\n" +
                    "Connection: Upgrade\r\nSec-WebSocket-Accept: $accept\r\n\r\n").toByteArray()
            )
            outs.flush()
            synchronized(lock) {
                try { client?.close() } catch (_: Exception) {}
                client = s
            }
            AppState.minecraft = true
            onLog("Minecraft connected")

            loop@ while (true) {
                val b0 = ins.read()
                val b1 = ins.read()
                if (b0 < 0 || b1 < 0) break
                val op = b0 and 0x0F
                var len = (b1 and 0x7F).toLong()
                if (len == 126L) {
                    len = ((ins.read() shl 8) or ins.read()).toLong()
                } else if (len == 127L) {
                    len = 0
                    for (i in 0 until 8) len = (len shl 8) or ins.read().toLong()
                }
                val masked = (b1 and 0x80) != 0
                val mask = ByteArray(4)
                if (masked) readFully(ins, mask)
                if (len > 1_000_000L) break
                val payload = ByteArray(len.toInt())
                readFully(ins, payload)
                if (masked) {
                    for (i in payload.indices) {
                        payload[i] = (payload[i].toInt() xor mask[i % 4].toInt()).toByte()
                    }
                }
                if (op == 8) break@loop
                if (op == 9) sendFrame(10, payload)
                if (op == 1) handleText(String(payload, Charsets.UTF_8))
            }
        } catch (_: Exception) {
        } finally {
            synchronized(lock) {
                if (client === s) {
                    client = null
                    AppState.minecraft = false
                    onLog("Minecraft disconnected")
                }
            }
            try { s.close() } catch (_: Exception) {}
        }
    }

    private fun handleText(text: String) {
        try {
            val j = JSONObject(text)
            if (j.optJSONObject("header")?.optString("messagePurpose") == "commandResponse") {
                val body = j.optJSONObject("body")
                if (body != null && body.optInt("statusCode", 0) < 0) {
                    onLog("Game says: " + body.optString("statusMessage"))
                }
            }
        } catch (_: Exception) {}
    }

    private fun sendFrame(op: Int, data: ByteArray) {
        synchronized(lock) {
            val c = client ?: return
            val o = c.getOutputStream()
            o.write(0x80 or op)
            when {
                data.size < 126 -> o.write(data.size)
                data.size < 65536 -> {
                    o.write(126); o.write(data.size shr 8); o.write(data.size and 0xFF)
                }
                else -> {
                    o.write(127)
                    for (i in 7 downTo 0) o.write((data.size.toLong() shr (8 * i)).toInt() and 0xFF)
                }
            }
            o.write(data)
            o.flush()
        }
    }

    /** Runs a slash command in the game (as the connected player). */
    fun sendCommand(cmd: String): Boolean {
        if (client == null) return false
        val msg = JSONObject()
            .put("header", JSONObject()
                .put("version", 1)
                .put("requestId", UUID.randomUUID().toString())
                .put("messageType", "commandRequest")
                .put("messagePurpose", "commandRequest"))
            .put("body", JSONObject()
                .put("version", 1)
                .put("commandLine", cmd)
                .put("origin", JSONObject().put("type", "player")))
        return try {
            sendFrame(1, msg.toString().toByteArray(Charsets.UTF_8))
            true
        } catch (e: Exception) {
            false
        }
    }
}
