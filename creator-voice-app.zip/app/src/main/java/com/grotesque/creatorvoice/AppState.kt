package com.grotesque.creatorvoice

object AppState {
    @Volatile var running = false
    @Volatile var listening = false
    @Volatile var minecraft = false
    private val lines = ArrayList<String>()

    @Synchronized fun log(s: String) {
        lines.add(s)
        while (lines.size > 8) lines.removeAt(0)
    }

    @Synchronized fun logText(): String = lines.joinToString("\n")
}
