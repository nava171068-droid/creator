package com.grotesque.creatorvoice

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

object Groq {
    private const val BASE = "https://api.groq.com/openai/v1"
    const val STT_MODEL = "whisper-large-v3-turbo"
    const val CHAT_MODEL = "llama-3.1-8b-instant"
    /** The Creator's name in many languages (the game reads the rest of the sentence itself). */
    val NAME_REGEX = Regex(
        "creator|criador|creador|cr[eé]ateur|creatore|sch(?:ö|o|oe)pfer|pencipta|создател\\p{L}*|творец|yarat[ıi]c[ıi]|tw[oó]rca|schepper|" +
            "ng[ưu][ờo]i t[ạa]o|ผู้สร้าง|ครีเอเตอร์|クリエイター|クリエーター|創造主|创造者|創造者|造物主|创造主|창조자|창조주|크리에이터",
        RegexOption.IGNORE_CASE
    )
    val FILLERS = setOf(
        "hey", "hello", "hi", "oh", "the", "ok", "okay", "oi", "ola", "olá", "ei", "hola", "salut", "hallo", "ciao",
        "привет", "สวัสดี", "ครับ", "ค่ะ"
    )
    val ACTIONS = setOf("summon", "give", "who", "music", "house", "rain", "clear", "none")

    private const val SYSTEM_PROMPT =
        "You are the brain of 'The Creator', a creepy entity in a Minecraft game. " +
        "The player spoke into a microphone (speech-to-text, may contain errors). The speech can be in ANY language " +
        "(English, Brazilian Portuguese, Spanish, Thai, ...): understand the meaning in any language. " +
        "Reply ONLY with JSON: {\"action\":\"...\",\"named\":false,\"item\":\"\",\"amount\":1}. " +
        "Set named=true if the player calls or addresses the Creator by name in any language (creator, criador, creador, créateur, Schöpfer, создатель, ผู้สร้าง, 创造者, クリエイター, 크리에이터 ...). Choose one action:\n" +
        "summon = the player calls the Creator by name (says 'creator') without any other request\n" +
        "rain = asks for rain, a storm, or bad weather\n" +
        "clear = asks to stop the rain, clear sky, sunny weather\n" +
        "house = asks to build or make a house\n" +
        "music = asks to play music, a song, or a music disc\n" +
        "give = asks to be given an item or asks for something. For give, set item to the Minecraft Bedrock item id " +
        "(lowercase snake_case, no namespace) that matches the MEANING of what was named, even if the wording differs " +
        "(e.g. 'sword made of diamonds' -> diamond_sword, 'golden apple' -> golden_apple). " +
        "Leave item empty if no specific item is named. amount = how many (default 1, 'a stack' = 64, max 64)\n" +
        "who = asks who or what the Creator is\n" +
        "none = anything else, normal chatter, unrelated speech, or silence noise like 'thank you'"

    private fun readBody(c: HttpURLConnection): String {
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
        if (code !in 200..299) throw IOException("Groq $code: ${text.take(160)}")
        return text
    }

    fun transcribe(key: String, wav: ByteArray): String {
        val boundary = "----cv" + System.currentTimeMillis()
        val c = URL("$BASE/audio/transcriptions").openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.doOutput = true
        c.connectTimeout = 10000
        c.readTimeout = 25000
        c.setRequestProperty("Authorization", "Bearer $key")
        c.setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
        c.outputStream.use { o ->
            fun field(n: String, v: String) {
                o.write("--$boundary\r\nContent-Disposition: form-data; name=\"$n\"\r\n\r\n$v\r\n".toByteArray())
            }
            field("model", STT_MODEL)
            field("response_format", "json")
            field("temperature", "0")
            field("prompt", "Creator, Criador, Creador, Créateur, Schöpfer, Создатель, ผู้สร้าง, 创造者, クリエイター, 크리에이터. Minecraft.")
            o.write(
                ("--$boundary\r\nContent-Disposition: form-data; name=\"file\"; filename=\"a.wav\"\r\n" +
                    "Content-Type: audio/wav\r\n\r\n").toByteArray()
            )
            o.write(wav)
            o.write("\r\n--$boundary--\r\n".toByteArray())
        }
        return JSONObject(readBody(c)).optString("text", "").trim()
    }

    fun classify(key: String, said: String): String {
        val body = JSONObject()
            .put("model", CHAT_MODEL)
            .put("temperature", 0)
            .put("max_tokens", 60)
            .put("response_format", JSONObject().put("type", "json_object"))
            .put("messages", JSONArray()
                .put(JSONObject().put("role", "system").put("content", SYSTEM_PROMPT))
                .put(JSONObject().put("role", "user").put("content", said)))
        val c = URL("$BASE/chat/completions").openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.doOutput = true
        c.connectTimeout = 10000
        c.readTimeout = 20000
        c.setRequestProperty("Authorization", "Bearer $key")
        c.setRequestProperty("Content-Type", "application/json")
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val content = JSONObject(readBody(c))
            .getJSONArray("choices").getJSONObject(0)
            .getJSONObject("message").getString("content")
        val j = JSONObject(content)
        val a = j.optString("action", "none").trim().lowercase()
        if (a !in ACTIONS) return "none"
        val named = if (j.optBoolean("named", false)) "1" else "0"
        if (a == "give") {
            val item = j.optString("item", "").lowercase().replace(Regex("[^a-z0-9_]"), "")
            val amount = j.optInt("amount", 1).coerceIn(1, 64)
            if (item.isNotEmpty()) return "give:$item:$amount|$named"
        }
        return "$a|$named"
    }

    /**
     * Backup when the AI call fails: only checks for the name. The action "unknown" makes the game
     * read the spoken words itself (it understands many languages, see scripts/intents.js).
     */
    fun keywordAction(said: String): String {
        val named = if (NAME_REGEX.containsMatchIn(said)) "1" else "0"
        return "unknown|$named"
    }
}
