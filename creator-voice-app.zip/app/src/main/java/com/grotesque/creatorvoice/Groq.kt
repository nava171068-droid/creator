package com.grotesque.creatorvoice

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

object Groq {
    private const val BASE = "https://api.groq.com/openai/v1"
    const val STT_MODEL = "whisper-large-v3-turbo"
    const val CHAT_MODEL = "llama-3.1-8b-instant"
    val ACTIONS = setOf("summon", "give", "who", "music", "house", "rain", "clear", "none")

    private const val SYSTEM_PROMPT =
        "You are the brain of 'The Creator', a creepy entity in a Minecraft game. " +
        "The player spoke into a microphone (speech-to-text, may contain errors). " +
        "Reply ONLY with JSON: {\"action\":\"...\"}. Choose one action:\n" +
        "summon = the player calls the Creator by name (says 'creator') without any other request\n" +
        "rain = asks for rain, a storm, or bad weather\n" +
        "clear = asks to stop the rain, clear sky, sunny weather\n" +
        "house = asks to build or make a house\n" +
        "music = asks to play music, a song, or a music disc\n" +
        "give = asks to be given an item or asks for something\n" +
        "who = asks who or what the Creator is\n" +
        "none = anything else, normal chatter, unrelated speech, or silence noise like 'thank you'"

    private fun readBody(c: HttpURLConnection): String {
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
        if (code !in 200..299) throw IOException("Groq $code: ${text.take(160)}")
        return text
    }

    fun transcribe(key: String, wav: ByteArray): String {
        val boundary = "----cv" + System.currentTimeMillis()
        val c = URL("$BASE/audio/transcriptions").openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.doOutput = true
        c.connectTimeout = 10000
        c.readTimeout = 25000
        c.setRequestProperty("Authorization", "Bearer $key")
        c.setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
        c.outputStream.use { o ->
            fun field(n: String, v: String) {
                o.write("--$boundary\r\nContent-Disposition: form-data; name=\"$n\"\r\n\r\n$v\r\n".toByteArray())
            }
            field("model", STT_MODEL)
            field("language", "en")
            field("response_format", "json")
            field("temperature", "0")
            field("prompt", "Creator. Minecraft.")
            o.write(
                ("--$boundary\r\nContent-Disposition: form-data; name=\"file\"; filename=\"a.wav\"\r\n" +
                    "Content-Type: audio/wav\r\n\r\n").toByteArray()
            )
            o.write(wav)
            o.write("\r\n--$boundary--\r\n".toByteArray())
        }
        return JSONObject(readBody(c)).optString("text", "").trim()
    }

    fun classify(key: String, said: String): String {
        val body = JSONObject()
            .put("model", CHAT_MODEL)
            .put("temperature", 0)
            .put("max_tokens", 30)
            .put("response_format", JSONObject().put("type", "json_object"))
            .put("messages", JSONArray()
                .put(JSONObject().put("role", "system").put("content", SYSTEM_PROMPT))
                .put(JSONObject().put("role", "user").put("content", said)))
        val c = URL("$BASE/chat/completions").openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.doOutput = true
        c.connectTimeout = 10000
        c.readTimeout = 20000
        c.setRequestProperty("Authorization", "Bearer $key")
        c.setRequestProperty("Content-Type", "application/json")
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val content = JSONObject(readBody(c))
            .getJSONArray("choices").getJSONObject(0)
            .getJSONObject("message").getString("content")
        val a = JSONObject(content).optString("action", "none").trim().lowercase()
        return if (a in ACTIONS) a else "none"
    }

    /** Backup when the AI call fails: simple keywords. */
    fun keywordAction(said: String): String {
        val t = said.lowercase()
        return when {
            Regex("stop (the )?rain|clear (the )?sky|sunny|sun out").containsMatchIn(t) -> "clear"
            Regex("rain|storm").containsMatchIn(t) -> "rain"
            Regex("house|build").containsMatchIn(t) -> "house"
            Regex("music|song|disc").containsMatchIn(t) -> "music"
            Regex("give|item").containsMatchIn(t) -> "give"
            Regex("who are you|what are you").containsMatchIn(t) -> "who"
            t.contains("creator") -> "summon"
            else -> "none"
        }
    }
}
