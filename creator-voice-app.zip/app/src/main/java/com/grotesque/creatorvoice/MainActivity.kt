package com.grotesque.creatorvoice

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var keyBox: EditText
    private lateinit var status: TextView
    private val ui = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            refresh()
            ui.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        val pad = (16 * d).toInt()
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(pad, pad * 2, pad, pad)

        fun text(s: String, size: Float): TextView {
            val t = TextView(this)
            t.text = s
            t.textSize = size
            return t
        }
        fun button(s: String, onClick: () -> Unit): Button {
            val b = Button(this)
            b.text = s
            b.setOnClickListener { onClick() }
            return b
        }

        col.addView(text("Creator Voice", 26f))
        col.addView(text("Say \"creator\" to call the Creator. Stand within 10 blocks of it and talk to it.", 15f))

        keyBox = EditText(this)
        keyBox.hint = "Groq API key (gsk_...)"
        keyBox.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        keyBox.setText(getSharedPreferences("cfg", MODE_PRIVATE).getString("key", ""))
        col.addView(keyBox)

        col.addView(button("1. Allow permissions") { askPermissions() })
        col.addView(button("2. Start floating mic") { start() })
        col.addView(button("Stop") {
            stopService(Intent(this, VoiceService::class.java))
        })

        status = text("", 15f)
        status.setPadding(0, pad, 0, 0)
        col.addView(status)

        val sv = ScrollView(this)
        sv.addView(col)
        setContentView(sv)
    }

    override fun onResume() {
        super.onResume()
        ui.post(tick)
    }

    override fun onPause() {
        ui.removeCallbacks(tick)
        saveKey()
        super.onPause()
    }

    private fun saveKey() {
        getSharedPreferences("cfg", MODE_PRIVATE).edit().putString("key", keyBox.text.toString().trim()).apply()
    }

    private fun askPermissions() {
        val list = ArrayList<String>()
        list.add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) list.add(Manifest.permission.POST_NOTIFICATIONS)
        requestPermissions(list.toTypedArray(), 1)
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
    }

    private fun start() {
        saveKey()
        if (keyBox.text.isBlank()) { Toast.makeText(this, "Paste your Groq API key first", Toast.LENGTH_LONG).show(); return }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED ||
            !Settings.canDrawOverlays(this)
        ) {
            Toast.makeText(this, "Tap \"1. Allow permissions\" first", Toast.LENGTH_LONG).show()
            return
        }
        startForegroundService(Intent(this, VoiceService::class.java))
    }

    private fun refresh() {
        val sb = StringBuilder()
        sb.append("Floating mic: ").append(if (AppState.running) "ON" else "OFF").append('\n')
        sb.append("Listening: ").append(if (AppState.listening) "yes" else "no").append('\n')
        sb.append("Minecraft: ").append(if (AppState.minecraft) "connected" else "not connected").append("\n\n")
        sb.append("In Minecraft (cheats on), type in chat:\n/connect localhost:19131\n\n")
        sb.append("Tap the floating mic to start/stop listening. Drag it to move it.\n\n")
        sb.append(AppState.logText())
        status.text = sb.toString()
    }
}
